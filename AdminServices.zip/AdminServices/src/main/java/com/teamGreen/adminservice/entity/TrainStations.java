package com.teamGreen.adminservice.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="trainstations")
public class TrainStations {
	
	@Id
	Integer trainNumber;
	String source;
	String destination;
	String intermediate1;
	String intermediate2;
	String intermediate3;
	String intermediate4;
	String intermediate5;
}
