package com.teamGreen.userSearchingService.service;

import java.util.ArrayList;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.teamGreen.userSearchingService.dto.TrainDto;

@Service
public class SearchService {
	
	ModelMapper mapper = new ModelMapper();

	List<TrainDto> trainDto = new ArrayList<TrainDto>();

	RestTemplate restTemplate = new RestTemplate();

	public List<TrainDto> getTrainByTrainNumber(Integer trainNumber) {
		String url = "http://localhost:8090/IRCTC/Admin/userSearchByTrainNumber";
		String uri = UriComponentsBuilder.fromUriString(url).queryParam("trainNumber", trainNumber).toUriString();
		
	    List<TrainDto> response = restTemplate.exchange(
	    		  uri,
	    		  HttpMethod.GET,
	    		  null,
	    		  new ParameterizedTypeReference<List<TrainDto>>() {}).getBody();
	   
		return response;
	}

	public List<TrainDto> getTrainByFromToDate(String source, String destination, String date) {
		String url = "http://localhost:8090/IRCTC/Admin/userSearchbyfromtodate";
		/*String uri = UriComponentsBuilder.fromUriString(url).queryParam("source", source)
		        .queryParam("destination", destination)
		        .queryParam("date", date).toUriString();*/
		
		String url1=url+"?"+"source="+source+"&destination="+destination+"&date="+date;
		List<TrainDto> trains = restTemplate.exchange(url1, HttpMethod.GET, null,  new ParameterizedTypeReference<List<TrainDto>>() {}).getBody();
		return trains;
	}

}
