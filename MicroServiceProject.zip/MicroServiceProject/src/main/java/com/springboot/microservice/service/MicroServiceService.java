package com.springboot.microservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.springboot.microservice.dto.CustomerDto;

@Service
public class MicroServiceService {

	@Autowired
	RestTemplate restTemplate;

	// get all customer from BankApplication client
	public List<CustomerDto> getCustomer() {
		return restTemplate.getForObject("http://localhost:8080/getAllCustomerDetails", List.class);
	}
}
