package com.springboot.microservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.microservice.dto.CustomerDto;
import com.springboot.microservice.service.MicroServiceService;

@RestController
public class MicroServiceController {
	
	@Autowired
	MicroServiceService microServiceService;
	
	@RequestMapping(value ="/template/getCustomer",method = RequestMethod.GET)
	public List<CustomerDto> getCustomer() {
		List<CustomerDto> customerList= (List<CustomerDto>) microServiceService.getCustomer();
		return customerList;
	}

}
