package com.springboot.moviebooking.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "shows")
public class Show {

	@Id
	@Column(name="showId")
	private String showId;
	
	@Column(name="theaterId")
	private String theaterId;
	
	@Column(name="date")
	private String date;
	
	@Column(name="morningShow")
	private String morningShow;
	
	@Column(name="noonShow")
	private String noonShow;
	
	@Column(name="eveningShow")
	private String eveningShow;
	

	public String getShowId() {
		return showId;
	}

	public void setShowId(String showId) {
		this.showId = showId;
	}

	public String getTheaterId() {
		return theaterId;
	}

	public void setTheaterId(String theaterId) {
		this.theaterId = theaterId;
	}



	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getMorningShow() {
		return morningShow;
	}

	public void setMorningShow(String morningShow) {
		this.morningShow = morningShow;
	}

	public String getNoonShow() {
		return noonShow;
	}

	public void setNoonShow(String noonShow) {
		this.noonShow = noonShow;
	}

	public String getEveningShow() {
		return eveningShow;
	}

	public void setEveningShow(String eveningShow) {
		this.eveningShow = eveningShow;
	}
	
	
}
