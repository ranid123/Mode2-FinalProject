package com.springboot.moviebooking.service;

import java.util.List;

import com.springboot.moviebooking.dto.TheaterDto;
import com.springboot.moviebooking.model.Show;

public interface ShowService {
	public String addShow(Show show);

	public List<TheaterDto> getTheatersForMovie(String movieName,String date);
}
