package com.springboot.moviebooking.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.springboot.moviebooking.model.Theater;

@Repository
public interface TheaterDAO extends CrudRepository<Theater, String> {

}
