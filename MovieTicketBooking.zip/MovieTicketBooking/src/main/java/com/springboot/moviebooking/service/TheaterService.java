package com.springboot.moviebooking.service;

import com.springboot.moviebooking.model.Theater;

public interface TheaterService {
	public String addTheater(Theater theater);
}
