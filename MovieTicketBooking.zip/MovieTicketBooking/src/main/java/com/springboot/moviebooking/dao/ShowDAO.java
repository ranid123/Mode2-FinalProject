package com.springboot.moviebooking.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.springboot.moviebooking.model.Show;

@Repository
public interface ShowDAO extends CrudRepository<Show,String>{

	@Query(value = " select * from shows s where s.morning_show= :movieName or s.evening_show= :movieName or s.noon_show= :movieName",nativeQuery= true)
	List<Show> showList(@Param("movieName") String movieName);
	
	@Query(value = " select * from shows s where s.morning_show= :movieName or s.evening_show= :movieName or s.noon_show= :movieName and s.date = :date",nativeQuery= true)
	List<Show> showListWithDate(@Param("movieName") String movieName,@Param("date") String date);

}
