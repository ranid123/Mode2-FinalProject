package com.springboot.moviebooking.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.moviebooking.dao.BookingDAO;
import com.springboot.moviebooking.dao.ShowDAO;
import com.springboot.moviebooking.dao.TheaterDAO;
import com.springboot.moviebooking.model.Booking;
import com.springboot.moviebooking.model.Theater;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	BookingDAO bookingdao;

	@Autowired
	ShowDAO showdao;

	@Autowired
	TheaterDAO theaterdao;
	ModelMapper mapper = new ModelMapper();

	//to add booking details to database
	@Override
	public Booking addBooking(String movieName, String theaterId, String userId, String showTime, String date) {
		Booking book = new Booking();
		Theater theater = theaterdao.findById(theaterId).orElse(null);
		book.setTheaterName(theater.getTheaterName());
		book.setDate(date);
		book.setMovieName(movieName);
		book.setUserId(userId);
		book.setShowTime(showTime);
		return book;
	}

}
