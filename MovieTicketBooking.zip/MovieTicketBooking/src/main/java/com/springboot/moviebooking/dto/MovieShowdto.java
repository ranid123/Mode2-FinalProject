package com.springboot.moviebooking.dto;

public class MovieShowdto {

}
