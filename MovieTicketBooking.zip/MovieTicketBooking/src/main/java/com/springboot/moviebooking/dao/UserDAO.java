package com.springboot.moviebooking.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.springboot.moviebooking.model.User;

@Repository
public interface UserDAO extends CrudRepository<User, String> {

}
