package com.springboot.moviebooking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.moviebooking.dao.TheaterDAO;
import com.springboot.moviebooking.model.Theater;

@Service
public class TheaterServiceImpl implements TheaterService {

	@Autowired
	TheaterDAO theaterdao;

	// to add theater details to database
	@Override
	public String addTheater(Theater theater) {
		theaterdao.save(theater);
		return "Successfully saved theaters";
	}

}
