package com.springboot.moviebooking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.moviebooking.dao.UserDAO;
import com.springboot.moviebooking.model.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDAO userdao;

	// to add user details to database
	@Override
	public String addUser(User user) {
		userdao.save(user);
		return "Successfully saved User";
	}

}
