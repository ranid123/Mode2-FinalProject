package com.springboot.moviebooking.service;

import java.util.List;

import com.springboot.moviebooking.model.Movie;

public interface MovieService {
	public String addMovie(Movie movie);
	public List<Movie> getMovies();
}
