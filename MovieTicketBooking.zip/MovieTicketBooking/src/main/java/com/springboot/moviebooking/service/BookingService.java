package com.springboot.moviebooking.service;

import com.springboot.moviebooking.model.Booking;

public interface BookingService {
	public Booking addBooking(String movieName,String theaterId,String userId,String showTime,String date);
}
