package com.springboot.moviebooking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.moviebooking.dto.TheaterDto;
import com.springboot.moviebooking.model.Movie;
import com.springboot.moviebooking.service.MovieService;
import com.springboot.moviebooking.service.ShowService;
import com.springboot.moviebooking.service.TheaterService;

@RestController
public class GetController {
	
	@Autowired
	TheaterService theaterservice;
	
	@Autowired
	ShowService showservice;
	
	@Autowired
	MovieService movieService;
	
	@RequestMapping(value="movie/get/getTheatersForMovie")
	public List<TheaterDto> getTheaterForMovie(@RequestParam String movieName,@RequestParam String date){
		return showservice.getTheatersForMovie(movieName,date);
	}

	@RequestMapping(value="movie/get/getMovies")
	public List<Movie> getMovies(){
		return movieService.getMovies();
	}
	


}
