package com.springboot.moviebooking.dto;

import java.util.ArrayList;
import java.util.List;

public class TheaterDto {

	private String theaterName;
	private String place;
	private List<String> showTime=new ArrayList<String>();

	/*
	 * private String morningShow; private String noonShow; private String
	 * eveningShow;
	 */
	public String getTheaterName() {
		return theaterName;
	}
	public void setTheaterName(String theaterName) {
		this.theaterName = theaterName;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}

	public List<String> getShowTime() {
		return showTime;
	}
	public void setShowTime(List<String> showTime) {
		this.showTime = showTime;
	}
	@Override
	public String toString() {
		return "TheaterDto [theaterName=" + theaterName + ", place=" + place + "]";
	}
	
	
}
