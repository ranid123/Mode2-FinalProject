package com.springboot.moviebooking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.moviebooking.model.Booking;
import com.springboot.moviebooking.model.Movie;
import com.springboot.moviebooking.model.Show;
import com.springboot.moviebooking.model.Theater;
import com.springboot.moviebooking.model.User;
import com.springboot.moviebooking.service.BookingService;
import com.springboot.moviebooking.service.MovieService;
import com.springboot.moviebooking.service.ShowService;
import com.springboot.moviebooking.service.TheaterService;
import com.springboot.moviebooking.service.UserService;

@RestController
public class SaveController {
	@Autowired
	TheaterService theaterservice;
	
	@Autowired
	ShowService showservice;
	
	@Autowired
	MovieService movieservice;
	
	@Autowired
	UserService userservice;
	
	@Autowired
	BookingService bookingservice;
	
	@PostMapping("add/addTheater")
	public String addTheaterDetails(@RequestBody Theater theater) {
		String message = (String) theaterservice.addTheater(theater);
		return message;
	}
	
	@PostMapping("movie/add/addShow")
	public String addShowDetails(@RequestBody Show show) {
		String message = (String) showservice.addShow(show);
		return message;
	}
	
	@PostMapping("movie/add/addMovie")
	public String addMovieDetails(@RequestBody Movie movie) {
		String message = (String) movieservice.addMovie(movie);
		return message;
	}
	
	@PostMapping("movie/add/addUser")
	public String addUserDetails(@RequestBody User user) {
		String message = (String) userservice.addUser(user);
		return message;
	}
	
	@PostMapping("movie/add/addBooking")
	public Booking addBookingDetails(@RequestParam String movieName,@RequestParam String theaterId,@RequestParam String userId,@RequestParam String showTime,@RequestParam String date) {
		return bookingservice.addBooking(movieName, theaterId, userId,showTime,date);
	}

}
