package com.springboot.moviebooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.moviebooking.dao.MovieDAO;
import com.springboot.moviebooking.model.Movie;

@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	MovieDAO moviedao;
	
	//to add movie details to database
	@Override
	public String addMovie(Movie movie) {
		// TODO Auto-generated method stub
		moviedao.save(movie);
		return "Successfully saved Movie";
	}
	
	//to get movie details from database
	@Override
	public List<Movie> getMovies() {
		// TODO Auto-generated method stub
		return (List<Movie>) moviedao.findAll();
	}

	
}
