package com.springboot.moviebooking.service;

import com.springboot.moviebooking.model.User;

public interface UserService {
	public String addUser(User user);
}
