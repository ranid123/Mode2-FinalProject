package com.springboot.moviebooking.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.springboot.moviebooking.model.Booking;

@Repository
public interface BookingDAO extends CrudRepository<Booking,Integer>{

}
