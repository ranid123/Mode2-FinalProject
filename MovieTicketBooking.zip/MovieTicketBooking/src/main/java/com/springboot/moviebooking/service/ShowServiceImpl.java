package com.springboot.moviebooking.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.moviebooking.dao.ShowDAO;
import com.springboot.moviebooking.dao.TheaterDAO;
import com.springboot.moviebooking.dto.TheaterDto;
import com.springboot.moviebooking.model.Show;
import com.springboot.moviebooking.model.Theater;

@Service
public class ShowServiceImpl implements ShowService {

	private static final Logger logger = LoggerFactory.getLogger(ShowServiceImpl.class);

	@Autowired
	ShowDAO showdao;

	@Autowired
	TheaterDAO theaterdao;

	ModelMapper mapper = new ModelMapper();

	// to add show details to database
	@Override
	public String addShow(Show show) {
		showdao.save(show);
		return "Successfully saved Shows";
	}

	List<String> showTimeList = new ArrayList<String>();

	// to get theater details for searched movie
	@Override
	public List<TheaterDto> getTheatersForMovie(String movieName, String date) {
		List<Show> show1 = showdao.showListWithDate(movieName, date);
		Iterator<Show> iterator = show1.iterator();
		Theater theaterObj = new Theater();
		List<TheaterDto> showList = new ArrayList<TheaterDto>();

		while (iterator.hasNext()) {
			TheaterDto theaterdto = new TheaterDto();
			Show show = iterator.next();
			theaterObj = theaterdao.findById(show.getTheaterId()).orElse(null);

			// theaterdto = mapper.map(show, TheaterDto.class);

			theaterdto.setTheaterName(theaterObj.getTheaterName());
			theaterdto.setPlace(theaterObj.getPlace());
			if (show.getMorningShow().equals(movieName)) {
				System.out.println("matched to morning show ");
				showTimeList.add("Morning Show");
				logger.info("showtime=" + showTimeList.get(0));

			}

			if (show.getNoonShow().equals(movieName)) {
				showTimeList.add("Noon Show");
				logger.info("showtime=" + showTimeList.get(1));
			}

			if (show.getEveningShow().equals(movieName)) {
				showTimeList.add("Evening Show");
				logger.info("showtime=" + showTimeList.get(2));
			}
			theaterdto.setShowTime(showTimeList);

			showList.add(theaterdto);
		}

		return showList;
	}

}
