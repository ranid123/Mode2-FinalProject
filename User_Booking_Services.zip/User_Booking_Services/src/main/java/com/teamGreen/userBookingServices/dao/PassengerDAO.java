package com.teamGreen.userBookingServices.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.teamGreen.userBookingServices.entity.Passenger;

@Repository
public interface PassengerDAO  extends CrudRepository<Passenger, Integer>{

}
