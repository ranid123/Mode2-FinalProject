package com.teamGreen.userBookingServices.dto;

import lombok.Data;

@Data
public class PassengerDetailsDto {

	String passengerName;
	Integer passengerId;
}
