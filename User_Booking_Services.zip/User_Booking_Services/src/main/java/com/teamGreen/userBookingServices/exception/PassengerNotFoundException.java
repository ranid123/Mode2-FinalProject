package com.teamGreen.userBookingServices.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.FORBIDDEN)
public class PassengerNotFoundException extends RuntimeException implements Runnable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PassengerNotFoundException(String exception) {
		super(exception);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		throw new PassengerNotFoundException("skjd");
	}

}
