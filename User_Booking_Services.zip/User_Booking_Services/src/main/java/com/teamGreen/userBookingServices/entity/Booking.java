package com.teamGreen.userBookingServices.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="booking")
public class Booking {
	@Id
Integer pnr;
Integer trainNumber;
LocalDate dateOfJourney;
String source;
String destination;
String startTime;
String endTime;
int noOfPassengers;
double totalFare;

public Booking() {
	super();
}
public Booking(Integer pnr, Integer trainNumber, LocalDate dateOfJourney, String source, String destination,
		String startTime, String endTime, int noOfPassengers, double totalFare) {
	super();
	this.pnr = pnr;
	this.trainNumber = trainNumber;
	this.dateOfJourney = dateOfJourney;
	this.source = source;
	this.destination = destination;
	this.startTime = startTime;
	this.endTime = endTime;
	this.noOfPassengers = noOfPassengers;
	this.totalFare = totalFare;
}
}
