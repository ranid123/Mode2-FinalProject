package com.teamGreen.userBookingServices.entity;

import lombok.Data;

@Data
public class Train 
{
	String startTime;
	int seatCount;
	double fare;
	String endTime;
	String trainName;
	TrainNumberandDate trainPrimaryKey;
	
}
