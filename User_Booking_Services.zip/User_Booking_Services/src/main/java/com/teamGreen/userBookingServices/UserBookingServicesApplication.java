package com.teamGreen.userBookingServices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableDiscoveryClient
@SpringBootApplication
public class UserBookingServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserBookingServicesApplication.class, args);
	}

}
