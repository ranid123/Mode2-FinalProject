package com.teamGreen.userService.Dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.teamGreen.userService.entity.Registration;

@Repository
public interface RegistrationDAO extends CrudRepository<Registration, Integer>{
	public Registration findByUserNameAndPasswrd(String userName,String passwrd);
}
