package com.teamGreen.userService.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="registration")
public class Registration 
{
	String userName;
	String passwrd;
	String phoneNumber;
	String email;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	Integer userId;
}