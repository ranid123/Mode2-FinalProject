package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Dto.TransactionDto;
import com.example.demo.model.Transactions;
import com.example.demo.service.TransactionService;

@RestController
public class TransactionalController {
	@Autowired
	TransactionService transactionService;

	@RequestMapping(value = "/bank/transaction/{custId}", method = RequestMethod.POST)
	public String transaction(@RequestBody TransactionDto transactions, @PathVariable Integer custId) {
		if (transactions.getTransactionType().equals("debit")) {
			return transactionService.debit(transactions, custId);
		} else if (transactions.getTransactionType().equals("credit")) {
			return transactionService.credit(transactions, custId);
		} else {
			return "Invalid TransactionType";
		}
	}

	@GetMapping(value = "/bank/gettransaction")
	public ResponseEntity<List<Transactions>> getTransactions(@RequestParam(defaultValue = "0") Integer pageNo,
			@RequestParam(defaultValue = "7") Integer pageSize, @RequestParam(defaultValue = "amount") String amount) {
		List<Transactions> list = transactionService.getPages(pageNo, pageSize, amount);

		return new ResponseEntity<List<Transactions>>(list, new HttpHeaders(), HttpStatus.OK);
	}
}
