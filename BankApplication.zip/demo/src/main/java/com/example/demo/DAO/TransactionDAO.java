
  package com.example.demo.DAO;
  
  import org.springframework.data.repository.PagingAndSortingRepository;

import com.example.demo.model.Transactions;
  
  
  //import com.example.demo.model.Transactions;
  
  public interface TransactionDAO extends PagingAndSortingRepository<Transactions, Integer>
  {
  
  }
 