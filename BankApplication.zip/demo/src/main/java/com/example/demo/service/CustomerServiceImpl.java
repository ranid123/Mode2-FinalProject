package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.AccountDAO;
import com.example.demo.DAO.CustomerDAO;
import com.example.demo.Dto.CustomerDto;
import com.example.demo.exceptions.CustomerNotFoundException;
import com.example.demo.model.Account;
import com.example.demo.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDAO customerDAO;
	@Autowired
	AccountDAO accountDAO;

	Account account = new Account();

	Generation generation = new Generation();
	ModelMapper mapper = new ModelMapper();

	// to add Customer details to database
	@Override
	public String addCustomerDetails(Customer customer) {
		customer.setPasswd(generation.password());
		customer.setId(generation.customerId());
		account.setCustId(customer.getId());
		account.setAccNo(generation.accountNo());
		account.setBalance(500000);
		if (customer.getAge() > 21) {
			if (!(String.valueOf(customer.getPhoneNo()).length() == 10)) {

				return "please enter a valid phone number";
			} else {
				customerDAO.save(customer);
				accountDAO.save(account);
				return "Your account successfully created";
			}
		} else {
			return "Your are not eligible";
		}
	}

	// to delete customer by id from database
	@Override
	public void deleteCustomerDetails(Integer customerId) {
		customerDAO.deleteById(customerId);
		accountDAO.deleteById(customerId);

	}

	List<CustomerDto> list = new ArrayList<CustomerDto>();

	// to get all customer from database
	@Override
	public List<CustomerDto> getAllCustomerDetails() {
		customerDAO.findAll().forEach(customer -> convertTo(customer));
		return list;
	}

	public void convertTo(Customer customer) {

		list.add(mapper.map(customer, CustomerDto.class));
	}

	// get customer by id
	@Override
	public Customer getCustomerById(Integer id) {
		return customerDAO.findById(id).orElse(null);
	}

	// to update customer emailId using CustomerId
	@Override
	public String updateCustomerById(Integer id, String email) {

		Customer customer = customerDAO.findById(id).orElse(null);
		if (customer == null) {
			throw new CustomerNotFoundException("Customer Not Found with id: " + id);
		} else {
			customer.setEmail(email);
		}
		customerDAO.save(customer);
		return "successfully updated";
	}

}
