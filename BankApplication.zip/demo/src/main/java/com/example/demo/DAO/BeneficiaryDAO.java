package com.example.demo.DAO;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Beneficiary;

public interface BeneficiaryDAO extends CrudRepository<Beneficiary, Integer> {

	public Beneficiary findByIFSCcode(String ifsc);

	public Beneficiary findByIFSCcodeAndBeneAccNo(String ifsc,String beneAccNo);

}
