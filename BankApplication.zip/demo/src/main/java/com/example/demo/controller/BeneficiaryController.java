package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Beneficiary;
import com.example.demo.service.BeneficiaryService;

@RestController
public class BeneficiaryController {
	@Autowired
	BeneficiaryService beneficiaryService;

	@PostMapping("/bank/addBeneficiary")
	public String addBeneficiaryDetails(@RequestBody Beneficiary beneficiary) {
		String message = (String) beneficiaryService.addBeneficiaryDetails(beneficiary);
		return message;
	}

	@RequestMapping(value = "/bank/getByIFSCcode/{ifsc}", method = RequestMethod.GET)
	public Beneficiary getBeneficiaryDetails(@PathVariable String ifsc) {
		return beneficiaryService.getBeneficiary(ifsc);
	}

	@RequestMapping(value = "/bank/getByIFSCcodeAndBAccNo/{ifsc}/{bAccNo}", method = RequestMethod.GET)
	public Beneficiary getBeneficiaryByIfscAndBAccNo(@PathVariable String ifsc, @PathVariable String bAccNo) {
		return beneficiaryService.getBeneficiaryByIfscAndBAccNo(ifsc, bAccNo);
	}

}
