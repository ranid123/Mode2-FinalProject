package com.example.demo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Customer;
@Repository
public interface CustomerDAO  extends CrudRepository<Customer, Integer>,JpaRepository<Customer, Integer>
{
	
	/*
	 * @Transactional
	 * 
	 * @Modifying(clearAutomatically=true)
	 * 
	 * @Query("update Customer customer SET customer.email=:email where customer.id=:id"
	 * ) void updateDetails(@Param("id") int custId,@Param("email") String
	 * custEmail);
	 */
	
	
	
}
