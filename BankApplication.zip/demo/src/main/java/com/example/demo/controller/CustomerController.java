package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Dto.CustomerDto;
import com.example.demo.model.Customer;
import com.example.demo.service.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	CustomerService customerService;

	@PostMapping("/bank/add")
	public String addCustomerDetails(@RequestBody Customer customer) {
		String message = (String) customerService.addCustomerDetails(customer);
		return message;
	}

	@RequestMapping(value = "/bank/delete/{id}", method = RequestMethod.GET)
	public void deleteCustomerDetails(@PathVariable Integer id) {
		customerService.deleteCustomerDetails(id);
	}

	@RequestMapping(value = "/bank/getAllCustomerDetails", method = RequestMethod.GET)
	public List<CustomerDto> getAllCustomerDetails() {
		return customerService.getAllCustomerDetails();
	}

	@RequestMapping(value = "/bank/getCustomerById/{id}", method = RequestMethod.GET)
	public Customer getCustomerDetails(@PathVariable Integer id) {
		return customerService.getCustomerById(id);
	}

	@RequestMapping(value = "/bank/updateCustomerById/{id}", method = RequestMethod.POST)
	public String updateCustomerDetails(@PathVariable Integer id, @RequestBody String email) {
		return customerService.updateCustomerById(id, email);
	}

}
