package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.example.demo.DAO.AccountDAO;
import com.example.demo.DAO.TransactionDAO;
import com.example.demo.Dto.TransactionDto;
import com.example.demo.exceptions.AccountNotFoundException;
import com.example.demo.exceptions.InsufficientBalanceException;
import com.example.demo.model.Account;
import com.example.demo.model.Transactions;

@Service
public class TransactionService {

	@Autowired
	AccountDAO accountDAO;
	@Autowired
	TransactionDAO transactionsDAO;
	Generation generation = new Generation();

	// method to debit from the account
	public String debit(TransactionDto transactions, Integer custId) {
		Account account = accountDAO.findById(custId).orElse(null);

		if (account == null) {
			throw new AccountNotFoundException("Account not found with customerId of id-" + custId);
		}

		else {
			if (transactions.getAmount() < account.getBalance()) {
				Transactions transaction = new Transactions();
				long balance = account.getBalance();
				System.out.println("Entered to debit method");
				balance -= transactions.getAmount();
				transaction.setCustId(account.getCustId());
				transaction.setTransactionType("debit");
				transaction.setAmount(transactions.getAmount());
				transaction.setAccNo(account.getAccNo());
				System.out.println(account.getAccNo());
				transaction.setDescription("debited : " + transactions.getAmount() + " from " + account.getAccNo());
				account.setBalance(balance);
				transactionsDAO.save(transaction);
				accountDAO.save(account);
				return "Successfully debited";
			} else {
				throw new InsufficientBalanceException("Insufficient balance with customerId of id-" + custId);
			}
		}
	}

	// method to credit from the account
	public String credit(TransactionDto transactionDto, Integer custId) {
		System.out.println("Credit method");
		List<Account> acc = (List<Account>) accountDAO.findAll();
		System.out.println(acc.get(0));
		List<Account> account1 = acc.stream().filter(x -> x.getAccNo().equals(transactionDto.getToAccNo()))
				.collect(Collectors.toList());
		Account account = accountDAO.findById(custId).orElse(null);
		if (account == null || account1 == null) {
			throw new AccountNotFoundException("Account Not Found Exception ");
		} else {
			if (account.getAccNo().equals(transactionDto.getToAccNo())) {
				System.out.println("Self");
				long balance1 = account.getBalance();
				Transactions transactions = new Transactions();
				balance1 += transactions.getAmount();
				transactions.setCustId(account.getCustId());
				transactions.setAccNo(transactionDto.getToAccNo());
				transactions.setAmount(transactionDto.getAmount());
				System.out.println(transactionDto.getToAccNo());
				transactions.setTransactionType("credit");
				transactions.setDescription("credited to self");
				account.setBalance(balance1);
				System.out.println("Insert to transaction table");
				transactionsDAO.save(transactions);
				accountDAO.save(account);
				return "Successfully creadited to your account";
			} else {
				System.out.println("credit with different from to");
				Transactions transaction1 = new Transactions();
				debit(transactionDto, custId);
				long balance2 = account1.get(0).getBalance();
				balance2 += transactionDto.getAmount();
				transaction1.setCustId(account1.get(0).getCustId());
				System.out.println("Amount: " + transactionDto.getAmount());

				transaction1.setAmount(transactionDto.getAmount());
				transaction1.setAccNo(account1.get(0).getAccNo());
				System.out.println(transactionDto.getToAccNo());

				transaction1.setTransactionType("credit");
				transaction1.setAmount(transactionDto.getAmount());
				transaction1.setDescription("credited:" + transactionDto.getAmount() + " from " + account.getCustId());
				account1.get(0).setBalance(balance2);
				transactionsDAO.save(transaction1);
				accountDAO.save(account1.get(0));
				return "Successfully creadited to your account";
			}
		}
	}

	// get all transactions using pagination
	public List<Transactions> getPages(Integer pageNo, Integer pageSize, String amount) {

		System.out.println("Pagination and sorting");
		Pageable pageInfo = PageRequest.of(pageNo, pageSize, Sort.by(amount));

		Page<Transactions> pagedResult = transactionsDAO.findAll(pageInfo);

		if (pagedResult.hasContent()) {

			return pagedResult.getContent();

		} else {

			return new ArrayList<Transactions>();

		}
	}

}
