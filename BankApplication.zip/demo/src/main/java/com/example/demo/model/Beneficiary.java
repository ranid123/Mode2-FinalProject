package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Beneficiary")
public class Beneficiary {

	private Integer custId;
	@Id
	private String beneAccNo;
	private String iFSCcode;
	public Integer getCustId() {
		return custId;
	}
	public void setCustId(Integer custId) {
		this.custId = custId;
	}
	
	public String getBeneAccNo() {
		return beneAccNo;
	}
	public void setBeneAccNo(String beneAccNo) {
		this.beneAccNo = beneAccNo;
	}
	public String getiFSCcode() {
		return iFSCcode;
	}
	public void setiFSCcode(String iFSCcode) {
		this.iFSCcode = iFSCcode;
	}
	
	
}
