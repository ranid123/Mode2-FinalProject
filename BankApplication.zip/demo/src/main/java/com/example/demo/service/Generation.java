package com.example.demo.service;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class Generation 
{
	String pswrd;
	String pswrd_shuffle;
	Random random = new Random();
	static Integer transactionid=1;
	List<String> pswrdList = new ArrayList<String>();
	
	//to generate password
	public String password() {
		final String CHAR_LOWER = "abcdefghijklmnopqrstuvwxyz";
		final String CHAR_UPPER = CHAR_LOWER.toUpperCase();
		final String NUMBER = "0123456789";
		final String OTHER_CHAR = "@#$*";

		pswrd = CHAR_LOWER + CHAR_UPPER + NUMBER + OTHER_CHAR;

		pswrd_shuffle = shuffleString(pswrd);
			 return generateRandomPassword(6);
	}

	public String shuffleString(String string) {
		List<String> letters = Arrays.asList(string.split(""));
		Collections.shuffle(letters);
		return letters.stream().collect(Collectors.joining());
	}

	public String generateRandomPassword(int length) {
		if (length < 1)
			throw new IllegalArgumentException();

		StringBuilder sb = new StringBuilder(length);
		for (int i = 0; i < length; i++) {

			int rndCharAt = random.nextInt(pswrd.length());
			char rndChar = pswrd.charAt(rndCharAt);
			sb.append(rndChar);
		}
		return sb.toString();
	}
	
	//to generate account Number
	public String accountNo()
	{
	int m = (int) Math.pow(10, 9);	
	int randm = m + new Random().nextInt(9 * m);
	String str="SB1"+randm;
	return str;
	}
	
	//to generate customerId
	public int customerId()
	{
		int m = (int) Math.pow(10, 3);	
		int randm = m + new Random().nextInt(9 * m);
		return randm;
	}

}

