package com.example.demo.service;

import com.example.demo.model.Beneficiary;

public interface BeneficiaryService {
	String addBeneficiaryDetails(Beneficiary beneficiary);
	
	public Beneficiary getBeneficiary(String IFSCcode);
	
	public Beneficiary getBeneficiaryByIfscAndBAccNo(String IFSCcode,String beneAccNo);
}
