package com.example.demo.service;

import java.util.List;
import com.example.demo.Dto.CustomerDto;
import com.example.demo.model.Customer;

public interface CustomerService {

	String addCustomerDetails(Customer customer);
	void deleteCustomerDetails(Integer customerId);
	List<CustomerDto> getAllCustomerDetails();
	 Customer getCustomerById(Integer id);
	 String updateCustomerById(Integer id, String email);
	// List<CustomerDto> getAllCustomerByBalance();
}
