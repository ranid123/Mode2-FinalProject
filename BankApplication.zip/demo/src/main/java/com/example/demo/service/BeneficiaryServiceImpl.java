package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.BeneficiaryDAO;
import com.example.demo.model.Beneficiary;

@Service
public class BeneficiaryServiceImpl implements BeneficiaryService {

	@Autowired
	BeneficiaryDAO beneficiaryDao;

	//to add beneficiary details to database
	@Override
	public String addBeneficiaryDetails(Beneficiary beneficiary) {
		beneficiaryDao.save(beneficiary);
		return "Successfully Saved";
	}

	//to get beneficiary details from database
	@Override
	public Beneficiary getBeneficiary(String ifsc) {

		return beneficiaryDao.findByIFSCcode(ifsc);
	}

	//to get beneficiary details by their IFSC and Beneficiary Account number
	@Override
	public Beneficiary getBeneficiaryByIfscAndBAccNo(String IFSCcode, String beneAccNo) {
		return beneficiaryDao.findByIFSCcodeAndBeneAccNo(IFSCcode, beneAccNo);
	}

}
